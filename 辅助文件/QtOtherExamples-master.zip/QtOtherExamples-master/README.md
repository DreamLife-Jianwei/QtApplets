﻿
![](https://github.com/zhengtianzuo/QtOtherExamples/blob/master/QtOtherExamples.jpg?raw=true)

# QtOtherExamples
Qt相关的技术分享

![](https://img.shields.io/badge/%E7%89%88%E6%9D%83%E8%AE%B8%E5%8F%AF-MIT-orange.svg)
![](https://img.shields.io/badge/Qt-5.10-blue.svg)
![](https://img.shields.io/badge/VS-2017-blue.svg)
![](https://img.shields.io/badge/%E7%89%88%E6%9C%AC-1.0.0.0-blue.svg)
![](https://img.shields.io/badge/%E7%BC%96%E8%AF%91-%E6%88%90%E5%8A%9F-brightgreen.svg)

QtZlibTest: Qt调用ZLib压缩解压

QtCamera: Qt操作摄像头


QtAudioDevices: Qt获取音频设备信息

![](https://github.com/zhengtianzuo/QtOtherExamples/blob/master/QtAudioDevices/show.png?raw=true)


QtLocalIP: Qt获取本地IP

![](https://github.com/zhengtianzuo/QtOtherExamples/blob/master/QtLocalIP/show.png?raw=true)


QtLog4Qt: Qt使用Log4Qt写日志

![](https://github.com/zhengtianzuo/QtOtherExamples/blob/master/QtLog4Qt/show.png?raw=true)


QtPlugin: Qt调用插件

![](https://github.com/zhengtianzuo/QtOtherExamples/blob/master/QtPlugin/QtMyPluginTest/show.gif?raw=true)

QtSingleApplication: Qt单实例进程

QtAutoStart: Qt设置开机启动

![](https://github.com/zhengtianzuo/QtOtherExamples/blob/master/QtAutoStart/show.png?raw=true)





#### 联系方式:
***
|作者|郑天佐|
|---|---
|QQ|278969898
|主页|http://www.camelstudio.cn/
|邮箱|camelsoft@163.com
|博客|http://blog.csdn.net/zhengtianzuo06/
|github|https://github.com/zhengtianzuo
|QQ群|199672080  ![](https://github.com/zhengtianzuo/zhengtianzuo.github.io/blob/master/qqgroup.jpg?raw=true)

<img src="https://github.com/zhengtianzuo/zhengtianzuo.github.io/blob/master/me.jpg?raw=true"/>

###### 觉得分享的内容还不错, 就请作者喝杯咖啡吧~~
***